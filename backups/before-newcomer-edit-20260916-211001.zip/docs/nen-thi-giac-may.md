# Nền: Thị giác máy nhúng

> Cho máy "nhìn". Chạy model thị giác trên board nhúng, đủ nhanh để dùng được thật.

---

## Đọc đoạn này trước, nó tiết kiệm thời gian cho cả hai bên

Nền này bị hiểu nhầm nhiều nhất. Phần lớn người mới nghe chữ "AI" rồi nghĩ tới một thứ, trong khi CLB đang làm một thứ khác hẳn. Nên phải nói thật rõ sự khác nhau đó ngay từ đầu.

### Hai thứ đều gọi là "AI" nhưng là hai nghề khác nhau

| | **AI mà đa số nghĩ tới** | **Thị giác máy nhúng — nghề ở đây** |
|---|---|---|
| **Chạy ở đâu** | Trên máy chủ mạnh hoặc dịch vụ đám mây | Trên board nhỏ gắn ngay trên thiết bị, chạy bằng pin |
| **Sức tính toán** | Gần như không giới hạn, thuê thêm là có | Cố định, ít ỏi, và nóng lên thì còn chậm nữa |
| **Đầu vào** | Dữ liệu sạch, đã chuẩn bị sẵn | Hình từ camera đang rung, ngược sáng, mờ, lệch góc |
| **Đầu ra** | Một câu trả lời, một con số, một đoạn văn | Một **hành động vật lý**: drone bay lệch trái, van đóng lại, còi kêu |
| **Thế nào là thành công** | Độ chính xác cao | Đủ chính xác **và** đủ nhanh **và** đủ ổn định suốt nhiều ngày |
| **Sai thì sao** | Trả lời sai, người dùng hỏi lại | Thiết bị hành động sai. Drone có thể rơi |
| **Thời gian dồn vào đâu** | Chọn và huấn luyện model | Tối ưu tốc độ, xử lý lỗi, ghép với phần cứng |

Nhìn bảng trên sẽ thấy: hai bên khác nhau không phải ở mức độ khó, mà ở **bản chất bài toán**. Bên trái là bài toán dữ liệu. Bên phải là bài toán kỹ thuật nhúng, chỉ có phần lõi là học máy.

### Cụ thể hơn

**Nền này KHÔNG phải:**

- **LLM, chatbot, AI tạo sinh.** Đây là nhánh hoàn toàn khác của AI, kỹ năng gần như không dùng chung được.
- **Train model rồi khoe chỉ số.** Ở đây, một model chính xác 99% mà chạy 2 khung hình mỗi giây là model bỏ đi; còn model chính xác 85% chạy 30 khung hình mỗi giây thì dùng được thật.
- **Nghiên cứu kiến trúc mạng nơ-ron mới.** Đó là việc của phòng nghiên cứu. CLB dùng model có sẵn và làm cho nó chạy được ở nơi nó cần chạy.

**Nền này LÀ:**

- Chạy model thị giác **trên board nhúng (VD: Pi 5, K230) gắn ngay trên thiết bị**, với điện năng và sức tính toán hạn chế
- Giữ đủ tốc độ khung hình để thiết bị phản ứng kịp lúc
- Lấy được hình ảnh dùng được từ camera gắn trên vật đang rung, đang di chuyển
- Và quan trọng nhất: **biến kết quả nhận diện thành một hành động thật**

### Điều khiến nhiều người bất ngờ

Cái khó của nền này **không nằm ở model**. Model là phần dễ nhất — có sẵn đầy, tải về là chạy.

Cái khó nằm ở ba chỗ, và cả ba đều là kỹ năng nhúng chứ không phải kỹ năng AI:

1. **Làm cho nó chạy nổi trên phần cứng yếu.** Thứ chạy mượt trên laptop có thể chậm hơn nhiều lần trên board nhúng.
2. **Làm cho nó chạy ổn định lâu dài.** Chạy tốt 5 phút thì dễ. Chạy tốt 5 ngày liên tục ngoài trời là chuyện khác hẳn.
3. **Làm cho thiết bị thật sự hành động theo nó.** Từ một khung màu trên ảnh tới một lệnh gửi xuống flight controller là cả một quãng đường.

**Nói gọn: nếu model của bạn chính xác 99% nhưng chạy quá chậm để thiết bị dùng được, bạn chưa làm xong việc.**

Nếu đọc tới đây mà thấy hụt hẫng vì nó không giống thứ bạn hình dung — tốt, bạn vừa tiết kiệm được vài tháng. Quay lại [ba mảng sản phẩm](ba-mang-san-pham.md) và chọn nền khác, không ai đánh giá gì cả. Còn nếu thấy đúng thứ mình muốn, đọc tiếp.

---

## Hợp với bạn nếu

- Bạn thích Python, và sẵn sàng học C++ khi cần tối ưu tốc độ
- Bạn thích bài toán "làm sao cho nó chạy nổi trên phần cứng yếu" hơn là "làm sao cho chỉ số đẹp hơn"
- Bạn chịu được việc thứ chạy mượt trên laptop lại chạy như rùa trên board nhúng

**Không hợp nếu** bạn chỉ muốn làm AI thuần. Ở CLB này, model không gắn lên thiết bị được thì chưa tính là xong.

---

## Điều kiện vào

Xong [Nền chung](00-ban-dang-o-dau.md#nền-chung--ai-cũng-phải-có), đặc biệt là **Linux/SSH** và **Python**. Bạn sẽ sống trên dòng lệnh của board nhúng.


---

## Phải học gì

### Chặng 1 — Làm chủ board nhúng

Trước khi nói tới AI, bạn phải điều khiển được cái máy sẽ chạy nó.

- Cài đặt và làm chủ một board nhúng (Raspberry Pi — CLB đã có repo hướng dẫn set up Pi 5)
- SSH vào board, làm việc hoàn toàn qua dòng lệnh, không cắm màn hình
- Quản lý môi trường Python, cài thư viện, xử lý khi phiên bản xung đột
- Hiểu tài nguyên board: bao nhiêu bộ nhớ, nóng tới đâu thì chậm lại, nguồn điện có đủ không

### Chặng 2 — Xử lý ảnh, chưa cần AI

Rất nhiều bài toán thật giải được ở chặng này mà không cần model nào. Đừng bỏ qua.

| Chủ đề | Bạn cần làm được gì |
|--------|---------------------|
| Lấy khung hình từ camera | Ổn định, liên tục, không rớt hình |
| Không gian màu và lọc ngưỡng | Tách vật thể theo màu |
| Tìm đường viền, tìm hình dạng | Xác định vị trí vật thể |
| Phát hiện marker | Cách đơn giản và rất đáng tin để định vị |
| **Đo tốc độ khung hình thật** | Và biết chỗ nào đang làm chậm |

**Bài tập nhỏ rất có ích:** phát hiện một vật màu rõ ràng, in ra toạ độ tâm theo thời gian thực. Nghe đơn giản, nhưng làm cho nó chạy ổn định ở tốc độ cao thì không đơn giản chút nào.

### Chặng 3 — Model học sâu trên board nhúng

| Chủ đề | Bạn cần làm được gì |
|--------|---------------------|
| Huấn luyện hoặc tinh chỉnh model phát hiện vật thể | Trên dữ liệu của CLB, không phải dữ liệu mẫu |
| **Tối ưu cho nhúng** | Lượng tử hoá model, chuyển sang định dạng chạy nhanh trên phần cứng đích |
| Dùng bộ tăng tốc phần cứng | Nếu CLB có |
| **Đo và so sánh** | Model gốc so với model đã tối ưu: nhanh hơn bao nhiêu, mất bao nhiêu độ chính xác |

Phần tối ưu là **cốt lõi của nền này**. Đây là chỗ bạn tạo ra giá trị mà người chỉ biết train model không tạo ra được.

### Chặng 4 — Biến kết quả thành hành động

Đây là chặng nối nền của bạn với phần còn lại của CLB. Không có chặng này thì bạn chỉ đang làm xử lý ảnh, không phải làm thiết bị.

- Chuyển từ toạ độ pixel trên ảnh sang hướng trong không gian thật
- Giao tiếp xuống vi điều khiển hoặc flight controller để gửi lệnh
- Bám mục tiêu ổn định qua các khung hình, xử lý khi mục tiêu bị che khuất tạm thời
- **Xử lý khi hỏng:** model nhận nhầm thì sao, camera mất tín hiệu thì sao, xử lý chậm quá thì sao

> **Quy tắc tuyệt đối:** mọi hành vi tự động phải chạy đúng trong mô phỏng trước khi đụng tới thiết bị thật. Không ai được thử code tự động lần đầu trên drone thật. Hệ thống phải luôn có đường lui về chế độ an toàn — không bao giờ được bay mù.

---

## Tự chấm: bạn đã có nền chưa

> **Bám một vật thể, trên board nhúng, đo được tốc độ thật.**
>
> Trên Raspberry Pi hoặc board CLB có, viết chương trình đọc camera thời gian thực, phát hiện một vật thể, in ra toạ độ tâm cùng **tốc độ khung hình đo được** ở mỗi khung.
>
> Cần có: code, video màn hình chạy thật trên board, và một đoạn ghi rõ **tốc độ khung hình đo được là bao nhiêu, nút thắt cổ chai nằm ở đâu, và bạn biết điều đó bằng cách nào**.

Phần cuối là phần quan trọng nhất. Nó phân biệt người chạy được code mẫu với người hiểu hệ thống mình đang chạy.

Chú ý: bài này **không yêu cầu dùng AI**. Làm bằng xử lý ảnh thông thường là đạt. Nếu bạn thấy bất ngờ vì điều đó, hãy đọc lại đoạn đầu file.

---

## Nền này dùng ở mảng nào

- **AIoT** — camera tự nhận diện tại chỗ, không cần gửi ảnh lên server
- **UAV** — bám mục tiêu, hạ cánh chính xác, bay dựa trên thị giác khi tín hiệu vệ tinh yếu

Chi tiết: [Ba mảng sản phẩm](ba-mang-san-pham.md)

---

## Tài nguyên

- **Tài liệu chính thức của thư viện thị giác và framework suy luận bạn dùng** — đọc đúng bản của phiên bản bạn cài
- [MAVLink Developer Guide](https://mavlink.io/en/) — nếu bạn đi vào mảng UAV. Đây là thứ nối nền của bạn với con drone. Không học phần này thì bạn chỉ đang làm xử lý ảnh
- [PX4 Autopilot Documentation](https://docs.px4.io/main/en/) — mục *Development*, đọc về cách máy tính phụ ghép vào hệ thống bay
- Repo `a.i-set-up-pi5` của CLB — hướng dẫn set up Pi 5

---

## Học tới đâu thì thị trường nhận

Nền này ít tin tuyển thẳng hơn hai nền kia, nên đọc theo cách khác: vào [nhóm tuyển dụng lập trình nhúng](https://web.facebook.com/groups/775890384111054) tìm các tin có **Edge AI**, **Computer Vision** hoặc **Embedded Linux**.

Điều bạn sẽ nhận ra: phần lớn yêu cầu là **kỹ năng nhúng**, không phải kỹ năng AI. Đó là lý do file này bắt bạn làm chủ board trước khi chạm vào model.

---

